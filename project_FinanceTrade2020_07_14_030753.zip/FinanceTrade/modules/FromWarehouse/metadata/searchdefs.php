<?php
$module_name = 'FinTr_FromWarehouse';
$_object_name = 'fintr_fromwarehouse';
$searchdefs [$module_name] = 
array (
  'layout' => 
  array (
    'basic_search' => 
    array (
      'name' => 
      array (
        'name' => 'name',
        'default' => true,
        'width' => '10%',
      ),
      'fintr_brand_fintr_fromwarehouse_name' => 
      array (
        'type' => 'relate',
        'link' => true,
        'label' => 'LBL_FINTR_BRAND_FINTR_FROMWAREHOUSE_FROM_FINTR_BRAND_TITLE',
        'id' => 'FINTR_BRAND_FINTR_FROMWAREHOUSEFINTR_BRAND_IDA',
        'width' => '10%',
        'default' => true,
        'name' => 'fintr_brand_fintr_fromwarehouse_name',
      ),
      'fintr_type_fintr_fromwarehouse_name' => 
      array (
        'type' => 'relate',
        'link' => true,
        'label' => 'LBL_FINTR_TYPE_FINTR_FROMWAREHOUSE_FROM_FINTR_TYPE_TITLE',
        'id' => 'FINTR_TYPE_FINTR_FROMWAREHOUSEFINTR_TYPE_IDA',
        'width' => '10%',
        'default' => true,
        'name' => 'fintr_type_fintr_fromwarehouse_name',
      ),
    ),
    'advanced_search' => 
    array (
      'name' => 
      array (
        'name' => 'name',
        'default' => true,
        'width' => '10%',
      ),
      'fintr_brand_fintr_fromwarehouse_name' => 
      array (
        'type' => 'relate',
        'link' => true,
        'label' => 'LBL_FINTR_BRAND_FINTR_FROMWAREHOUSE_FROM_FINTR_BRAND_TITLE',
        'width' => '10%',
        'default' => true,
        'id' => 'FINTR_BRAND_FINTR_FROMWAREHOUSEFINTR_BRAND_IDA',
        'name' => 'fintr_brand_fintr_fromwarehouse_name',
      ),
      'fintr_type_fintr_fromwarehouse_name' => 
      array (
        'type' => 'relate',
        'link' => true,
        'label' => 'LBL_FINTR_TYPE_FINTR_FROMWAREHOUSE_FROM_FINTR_TYPE_TITLE',
        'width' => '10%',
        'default' => true,
        'id' => 'FINTR_TYPE_FINTR_FROMWAREHOUSEFINTR_TYPE_IDA',
        'name' => 'fintr_type_fintr_fromwarehouse_name',
      ),
      'assigned_user_id' => 
      array (
        'name' => 'assigned_user_id',
        'type' => 'enum',
        'label' => 'LBL_ASSIGNED_TO',
        'function' => 
        array (
          'name' => 'get_user_array',
          'params' => 
          array (
            0 => false,
          ),
        ),
        'default' => true,
        'width' => '10%',
      ),
      'fintr_fromwarehouse_number' => 
      array (
        'name' => 'fintr_fromwarehouse_number',
        'default' => true,
        'width' => '10%',
      ),
    ),
  ),
  'templateMeta' => 
  array (
    'maxColumns' => '3',
    'maxColumnsBasic' => '4',
    'widths' => 
    array (
      'label' => '10',
      'field' => '30',
    ),
  ),
);
?>
