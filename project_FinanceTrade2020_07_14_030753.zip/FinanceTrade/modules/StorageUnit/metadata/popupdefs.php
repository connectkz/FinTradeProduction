<?php
$popupMeta = array (
    'moduleMain' => 'FinTr_StorageUnit',
    'varName' => 'FinTr_StorageUnit',
    'orderBy' => 'fintr_storageunit.name',
    'whereClauses' => array (
  'name' => 'fintr_storageunit.name',
  'serial_number' => 'fintr_storageunit.serial_number',
),
    'searchInputs' => array (
  1 => 'name',
  4 => 'serial_number',
),
    'searchdefs' => array (
  'name' => 
  array (
    'type' => 'name',
    'link' => true,
    'label' => 'LBL_NAME',
    'width' => '10%',
    'name' => 'name',
  ),
  'serial_number' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_SERIAL_NUMBER',
    'width' => '10%',
    'name' => 'serial_number',
  ),
),
    'listviewdefs' => array (
  'NAME' => 
  array (
    'type' => 'name',
    'link' => true,
    'label' => 'LBL_NAME',
    'width' => '10%',
    'default' => true,
    'name' => 'name',
  ),
  'VALUE_IN_STORAGEUNIT' => 
  array (
    'type' => 'decimal',
    'label' => 'LBL_VALUE_IN_STORAGEUNIT',
    'width' => '10%',
    'default' => true,
    'name' => 'value_in_storageunit',
  ),
  'SERIAL_NUMBER' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_SERIAL_NUMBER',
    'width' => '10%',
    'default' => true,
    'name' => 'serial_number',
  ),
),
);
