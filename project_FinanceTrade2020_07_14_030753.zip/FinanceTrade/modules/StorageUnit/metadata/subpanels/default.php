<?php
$module_name='FinTr_StorageUnit';
$subpanel_layout = array (
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'popup_module' => 'FinTr_StorageUnit',
    ),
  ),
  'where' => '',
  'list_fields' => 
  array (
    'name' => 
    array (
      'vname' => 'LBL_NAME',
      'widget_class' => 'SubPanelDetailViewLink',
      'width' => '45%',
      'default' => true,
    ),
    'value_in_storageunit' => 
    array (
      'type' => 'decimal',
      'vname' => 'LBL_VALUE_IN_STORAGEUNIT',
      'width' => '10%',
      'default' => true,
    ),
    'serial_number' => 
    array (
      'type' => 'varchar',
      'vname' => 'LBL_SERIAL_NUMBER',
      'width' => '10%',
      'default' => true,
    ),
    'place' => 
    array (
      'type' => 'varchar',
      'vname' => 'LBL_PLACE',
      'width' => '10%',
      'default' => true,
    ),
  ),
);