<?php
$module_name='FinTr_model';
$subpanel_layout = array (
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'popup_module' => 'FinTr_model',
    ),
  ),
  'where' => '',
  'list_fields' => 
  array (
    'name' => 
    array (
      'vname' => 'LBL_NAME',
      'widget_class' => 'SubPanelDetailViewLink',
      'width' => '45%',
      'default' => true,
    ),
    'serialnumber' => 
    array (
      'type' => 'enum',
      'studio' => 'visible',
      'vname' => 'LBL_SERIALNUMBER',
      'width' => '10%',
      'default' => true,
    ),
    'merged' => 
    array (
      'type' => 'enum',
      'studio' => 'visible',
      'vname' => 'LBL_MERGED',
      'width' => '10%',
      'default' => true,
    ),
    'edit_button' => 
    array (
      'vname' => 'LBL_EDIT_BUTTON',
      'widget_class' => 'SubPanelEditButton',
      'module' => 'FinTr_model',
      'width' => '4%',
      'default' => true,
    ),
    'remove_button' => 
    array (
      'vname' => 'LBL_REMOVE',
      'widget_class' => 'SubPanelRemoveButton',
      'module' => 'FinTr_model',
      'width' => '5%',
      'default' => true,
    ),
  ),
);