<?php
$module_name='FinTr_ToWarehouse';
$subpanel_layout = array (
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'popup_module' => 'FinTr_ToWarehouse',
    ),
  ),
  'where' => '',
  'list_fields' => 
  array (
    'name' => 
    array (
      'vname' => 'LBL_SUBJECT',
      'widget_class' => 'SubPanelDetailViewLink',
      'width' => '45%',
      'default' => true,
    ),
    'valuein' => 
    array (
      'type' => 'decimal',
      'vname' => 'LBL_VALUEIN',
      'width' => '10%',
      'default' => true,
    ),
    'place' => 
    array (
      'type' => 'varchar',
      'vname' => 'LBL_PLACE',
      'width' => '10%',
      'default' => true,
    ),
    'serial_number' => 
    array (
      'type' => 'varchar',
      'vname' => 'LBL_SERIAL_NUMBER',
      'width' => '10%',
      'default' => true,
    ),
    'assigned_user_name' => 
    array (
      'name' => 'assigned_user_name',
      'vname' => 'LBL_ASSIGNED_TO_NAME',
      'widget_class' => 'SubPanelDetailViewLink',
      'target_record_key' => 'assigned_user_id',
      'target_module' => 'Employees',
      'width' => '10%',
      'default' => true,
    ),
    'date_in' => 
    array (
      'type' => 'date',
      'vname' => 'LBL_DATE_IN',
      'width' => '10%',
      'default' => true,
    ),
    'fintr_towarehouse_number' => 
    array (
      'type' => 'int',
      'studio' => 
      array (
        'quickcreate' => false,
      ),
      'vname' => 'LBL_NUMBER',
      'width' => '10%',
      'default' => true,
    ),
  ),
);