<?php
$popupMeta = array (
    'moduleMain' => 'FinTr_CashIn',
    'varName' => 'FinTr_CashIn',
    'orderBy' => 'fintr_cashin.name',
    'whereClauses' => array (
  'fintr_cashin_number' => 'fintr_cashin.fintr_cashin_number',
  'type' => 'fintr_cashin.type',
  'currency' => 'fintr_cashin.currency',
  'date_entered' => 'fintr_cashin.date_entered',
),
    'searchInputs' => array (
  0 => 'fintr_cashin_number',
  4 => 'type',
  5 => 'currency',
  6 => 'date_entered',
),
    'searchdefs' => array (
  'fintr_cashin_number' => 
  array (
    'type' => 'int',
    'studio' => 
    array (
      'quickcreate' => false,
    ),
    'label' => 'LBL_NUMBER',
    'width' => '10%',
    'name' => 'fintr_cashin_number',
  ),
  'type' => 
  array (
    'type' => 'enum',
    'studio' => 'visible',
    'label' => 'LBL_TYPE',
    'width' => '10%',
    'name' => 'type',
  ),
  'currency' => 
  array (
    'type' => 'currency',
    'label' => 'LBL_CURRENCY',
    'currency_format' => true,
    'width' => '10%',
    'name' => 'currency',
  ),
  'date_entered' => 
  array (
    'type' => 'datetime',
    'label' => 'LBL_DATE_ENTERED',
    'width' => '10%',
    'name' => 'date_entered',
  ),
),
    'listviewdefs' => array (
  'FINTR_CASHIN_NUMBER' => 
  array (
    'type' => 'int',
    'studio' => 
    array (
      'quickcreate' => false,
    ),
    'label' => 'LBL_NUMBER',
    'width' => '10%',
    'default' => true,
  ),
  'DATE_ENTERED' => 
  array (
    'type' => 'datetime',
    'label' => 'LBL_DATE_ENTERED',
    'width' => '10%',
    'default' => true,
  ),
  'CURRENCY' => 
  array (
    'type' => 'currency',
    'label' => 'LBL_CURRENCY',
    'currency_format' => true,
    'width' => '10%',
    'default' => true,
  ),
  'ASSIGNED_USER_NAME' => 
  array (
    'link' => true,
    'type' => 'relate',
    'label' => 'LBL_ASSIGNED_TO_NAME',
    'id' => 'ASSIGNED_USER_ID',
    'width' => '10%',
    'default' => true,
  ),
  'TYPE' => 
  array (
    'type' => 'enum',
    'default' => true,
    'studio' => 'visible',
    'label' => 'LBL_TYPE',
    'width' => '10%',
  ),
  'NAME' => 
  array (
    'type' => 'name',
    'link' => true,
    'label' => 'LBL_SUBJECT',
    'width' => '10%',
    'default' => true,
  ),
),
);
