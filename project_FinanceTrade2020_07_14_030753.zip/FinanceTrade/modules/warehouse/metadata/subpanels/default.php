<?php
$module_name='FinTr_warehouse';
$subpanel_layout = array (
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'popup_module' => 'FinTr_warehouse',
    ),
  ),
  'where' => '',
  'list_fields' => 
  array (
    'name' => 
    array (
      'vname' => 'LBL_NAME',
      'widget_class' => 'SubPanelDetailViewLink',
      'width' => '45%',
      'default' => true,
    ),
    'sum' => 
    array (
      'type' => 'decimal',
      'vname' => 'LBL_SUM',
      'width' => '10%',
      'default' => true,
    ),
    'with_docu' => 
    array (
      'type' => 'decimal',
      'vname' => 'LBL_WITH_DOCU',
      'width' => '10%',
      'default' => true,
    ),
    'without_docu' => 
    array (
      'type' => 'decimal',
      'vname' => 'LBL_WITHOUT_DOCU',
      'width' => '10%',
      'default' => true,
    ),
  ),
);