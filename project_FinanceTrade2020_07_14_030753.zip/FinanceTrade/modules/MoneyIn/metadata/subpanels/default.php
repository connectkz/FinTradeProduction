<?php
$module_name='FinTr_MoneyIn';
$subpanel_layout = array (
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'popup_module' => 'FinTr_MoneyIn',
    ),
  ),
  'where' => '',
  'list_fields' => 
  array (
    'money_in' => 
    array (
      'type' => 'currency',
      'vname' => 'LBL_MONEY_IN',
      'currency_format' => true,
      'width' => '10%',
      'default' => true,
    ),
    'blackcash' => 
    array (
      'type' => 'bool',
      'default' => true,
      'vname' => 'LBL_BLACKCASH',
      'width' => '10%',
    ),
    'name' => 
    array (
      'vname' => 'LBL_SUBJECT',
      'widget_class' => 'SubPanelDetailViewLink',
      'width' => '45%',
      'default' => true,
    ),
    'money_in_via' => 
    array (
      'type' => 'enum',
      'default' => true,
      'studio' => 'visible',
      'vname' => 'LBL_MONEY_IN_VIA',
      'width' => '10%',
    ),
    'edit_button' => 
    array (
      'vname' => 'LBL_EDIT_BUTTON',
      'widget_class' => 'SubPanelEditButton',
      'module' => 'FinTr_MoneyIn',
      'width' => '4%',
      'default' => true,
    ),
    'remove_button' => 
    array (
      'vname' => 'LBL_REMOVE',
      'widget_class' => 'SubPanelRemoveButton',
      'module' => 'FinTr_MoneyIn',
      'width' => '5%',
      'default' => true,
    ),
  ),
);