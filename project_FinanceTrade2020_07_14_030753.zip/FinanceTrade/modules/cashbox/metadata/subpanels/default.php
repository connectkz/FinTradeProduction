<?php
$module_name='FinTr_cashbox';
$subpanel_layout = array (
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'popup_module' => 'FinTr_cashbox',
    ),
  ),
  'where' => '',
  'list_fields' => 
  array (
    'assigned_user_name' => 
    array (
      'name' => 'assigned_user_name',
      'vname' => 'LBL_ASSIGNED_TO_NAME',
      'widget_class' => 'SubPanelDetailViewLink',
      'target_record_key' => 'assigned_user_id',
      'target_module' => 'Employees',
      'width' => '10%',
      'default' => true,
    ),
  ),
);