<?php
$module_name = 'FinTr_cashbox';
$OBJECT_NAME = 'FINTR_CASHBOX';
$listViewDefs [$module_name] = 
array (
  'NAME' => 
  array (
    'type' => 'name',
    'link' => true,
    'label' => 'LBL_SUBJECT',
    'width' => '10%',
    'default' => true,
  ),
  'DESCRIPTION' => 
  array (
    'type' => 'text',
    'label' => 'LBL_DESCRIPTION',
    'sortable' => false,
    'width' => '10%',
    'default' => true,
  ),
  'CURRENCY' => 
  array (
    'type' => 'currency',
    'label' => 'LBL_CURRENCY',
    'currency_format' => true,
    'width' => '10%',
    'default' => true,
  ),
  'CASHCREDIT' => 
  array (
    'type' => 'currency',
    'label' => 'LBL_CASHCREDIT',
    'currency_format' => true,
    'width' => '10%',
    'default' => true,
  ),
  'CASHDEBET' => 
  array (
    'type' => 'currency',
    'label' => 'LBL_CASHDEBET',
    'currency_format' => true,
    'width' => '10%',
    'default' => true,
  ),
  'ASSIGNED_USER_NAME' => 
  array (
    'width' => '9%',
    'label' => 'LBL_ASSIGNED_USER',
    'module' => 'Employees',
    'id' => 'ASSIGNED_USER_ID',
    'default' => true,
  ),
  'DATE_MODIFIED' => 
  array (
    'type' => 'datetime',
    'label' => 'LBL_DATE_MODIFIED',
    'width' => '10%',
    'default' => true,
  ),
);
?>
