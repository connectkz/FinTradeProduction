<?php
/*********************************************************************************
 * SugarCRM Community Edition is a customer relationship management program developed by
 * SugarCRM, Inc. Copyright (C) 2004-2013 SugarCRM Inc.
 * 
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by the
 * Free Software Foundation with the addition of the following permission added
 * to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED WORK
 * IN WHICH THE COPYRIGHT IS OWNED BY SUGARCRM, SUGARCRM DISCLAIMS THE WARRANTY
 * OF NON INFRINGEMENT OF THIRD PARTY RIGHTS.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU Affero General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU Affero General Public License along with
 * this program; if not, see http://www.gnu.org/licenses or write to the Free
 * Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
 * 02110-1301 USA.
 * 
 * You can contact SugarCRM, Inc. headquarters at 10050 North Wolfe Road,
 * SW2-130, Cupertino, CA 95014, USA. or at email address contact@sugarcrm.com.
 * 
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 * 
 * In accordance with Section 7(b) of the GNU Affero General Public License version 3,
 * these Appropriate Legal Notices must retain the display of the "Powered by
 * SugarCRM" logo. If the display of the logo is not reasonably feasible for
 * technical reasons, the Appropriate Legal Notices must display the words
 * "Powered by SugarCRM".
 ********************************************************************************/


$app_list_strings['moduleList']['FinTr_cashbox'] = 'Касса';
$app_list_strings['moduleList']['FinTr_Bank'] = 'Банк';
$app_list_strings['moduleList']['FinTr_MoneyIn'] = 'Доходы';
$app_list_strings['moduleList']['FinTr_MoneyOut'] = 'Расходы';
$app_list_strings['moduleList']['FinTr_goods'] = 'ТМЗ';
$app_list_strings['moduleList']['FinTr_warehouse'] = 'Склад';
$app_list_strings['moduleList']['FinTr_brand'] = 'Бренд';
$app_list_strings['moduleList']['FinTr_model'] = 'Модель/марка';
$app_list_strings['moduleList']['FinTr_Type'] = 'Тип оборудования';
$app_list_strings['moduleList']['FinTr_StorageUnit'] = 'Складские единицы';
$app_list_strings['moduleList']['FinTr_ToWarehouse'] = 'Поступление на склад';
$app_list_strings['moduleList']['FinTr_FromWarehouse'] = 'Выдача со склада';
$app_list_strings['moduleList']['FinTr_goodsIn'] = 'Приобретение';
$app_list_strings['moduleList']['FinTr_goodsOut'] = 'Продажа';
$app_list_strings['moduleList']['FinTr_CashIn'] = 'В кассу';
$app_list_strings['moduleList']['FinTr_CashOut'] = 'Из кассы';
$app_list_strings['moduleList']['FinTr_CashCredit'] = 'Деньги под отчёт';
$app_list_strings['moduleList']['FinTr_BankIn'] = 'В банк';
$app_list_strings['moduleList']['FinTr_BankOut'] = 'Из банка';
$app_list_strings['moduleList']['FinTr_GoodsCredit'] = 'Материалы под отчёт';
$app_list_strings['moduleList']['FinTr_stockman'] = 'Склады и кладовщики';
$app_list_strings['fintr_cashbox_type_dom']['Administration'] = 'Ведение';
$app_list_strings['fintr_cashbox_type_dom']['Product'] = 'Результат';
$app_list_strings['fintr_cashbox_type_dom']['User'] = 'Клиентское';
$app_list_strings['fintr_cashbox_status_dom']['New'] = 'Новое';
$app_list_strings['fintr_cashbox_status_dom']['Assigned'] = 'Назначенное';
$app_list_strings['fintr_cashbox_status_dom']['Closed'] = 'Закрытое';
$app_list_strings['fintr_cashbox_status_dom']['Pending Input'] = 'Ожидание решения';
$app_list_strings['fintr_cashbox_status_dom']['Rejected'] = 'Отклоненное';
$app_list_strings['fintr_cashbox_status_dom']['Duplicate'] = 'Дублировать';
$app_list_strings['fintr_cashbox_priority_dom']['P1'] = 'Высокий';
$app_list_strings['fintr_cashbox_priority_dom']['P2'] = 'Средний';
$app_list_strings['fintr_cashbox_priority_dom']['P3'] = 'Низкий';
$app_list_strings['fintr_cashbox_resolution_dom'][''] = '';
$app_list_strings['fintr_cashbox_resolution_dom']['Accepted'] = 'Принято';
$app_list_strings['fintr_cashbox_resolution_dom']['Duplicate'] = 'Дублировать';
$app_list_strings['fintr_cashbox_resolution_dom']['Closed'] = 'Закрытое';
$app_list_strings['fintr_cashbox_resolution_dom']['Out of Date'] = 'Устарело';
$app_list_strings['fintr_cashbox_resolution_dom']['Invalid'] = 'Недействительно';
$app_list_strings['fintr_bank_type_dom']['Administration'] = 'Ведение';
$app_list_strings['fintr_bank_type_dom']['Product'] = 'Результат';
$app_list_strings['fintr_bank_type_dom']['User'] = 'Клиентское';
$app_list_strings['fintr_bank_status_dom']['New'] = 'Новое';
$app_list_strings['fintr_bank_status_dom']['Assigned'] = 'Назначенное';
$app_list_strings['fintr_bank_status_dom']['Closed'] = 'Закрытое';
$app_list_strings['fintr_bank_status_dom']['Pending Input'] = 'Ожидание решения';
$app_list_strings['fintr_bank_status_dom']['Rejected'] = 'Отклоненное';
$app_list_strings['fintr_bank_status_dom']['Duplicate'] = 'Дублировать';
$app_list_strings['fintr_bank_priority_dom']['P1'] = 'Высокий';
$app_list_strings['fintr_bank_priority_dom']['P2'] = 'Средний';
$app_list_strings['fintr_bank_priority_dom']['P3'] = 'Низкий';
$app_list_strings['fintr_bank_resolution_dom'][''] = '';
$app_list_strings['fintr_bank_resolution_dom']['Accepted'] = 'Принято';
$app_list_strings['fintr_bank_resolution_dom']['Duplicate'] = 'Дублировать';
$app_list_strings['fintr_bank_resolution_dom']['Closed'] = 'Закрытое';
$app_list_strings['fintr_bank_resolution_dom']['Out of Date'] = 'Устарело';
$app_list_strings['fintr_bank_resolution_dom']['Invalid'] = 'Недействительно';
$app_list_strings['fintr_moneyin_type_dom']['Administration'] = 'Ведение';
$app_list_strings['fintr_moneyin_type_dom']['Product'] = 'Результат';
$app_list_strings['fintr_moneyin_type_dom']['User'] = 'Клиентское';
$app_list_strings['fintr_moneyin_status_dom']['New'] = 'Новое';
$app_list_strings['fintr_moneyin_status_dom']['Assigned'] = 'Назначенное';
$app_list_strings['fintr_moneyin_status_dom']['Closed'] = 'Закрытое';
$app_list_strings['fintr_moneyin_status_dom']['Pending Input'] = 'Ожидание решения';
$app_list_strings['fintr_moneyin_status_dom']['Rejected'] = 'Отклоненное';
$app_list_strings['fintr_moneyin_status_dom']['Duplicate'] = 'Дублировать';
$app_list_strings['fintr_moneyin_priority_dom']['P1'] = 'Высокий';
$app_list_strings['fintr_moneyin_priority_dom']['P2'] = 'Средний';
$app_list_strings['fintr_moneyin_priority_dom']['P3'] = 'Низкий';
$app_list_strings['fintr_moneyin_resolution_dom'][''] = '';
$app_list_strings['fintr_moneyin_resolution_dom']['Accepted'] = 'Принято';
$app_list_strings['fintr_moneyin_resolution_dom']['Duplicate'] = 'Дублировать';
$app_list_strings['fintr_moneyin_resolution_dom']['Closed'] = 'Закрытое';
$app_list_strings['fintr_moneyin_resolution_dom']['Out of Date'] = 'Устарело';
$app_list_strings['fintr_moneyin_resolution_dom']['Invalid'] = 'Недействительно';
$app_list_strings['fintr_moneyout_type_dom']['Administration'] = 'Ведение';
$app_list_strings['fintr_moneyout_type_dom']['Product'] = 'Результат';
$app_list_strings['fintr_moneyout_type_dom']['User'] = 'Клиентское';
$app_list_strings['fintr_moneyout_status_dom']['New'] = 'Новое';
$app_list_strings['fintr_moneyout_status_dom']['Assigned'] = 'Назначенное';
$app_list_strings['fintr_moneyout_status_dom']['Closed'] = 'Закрытое';
$app_list_strings['fintr_moneyout_status_dom']['Pending Input'] = 'Ожидание решения';
$app_list_strings['fintr_moneyout_status_dom']['Rejected'] = 'Отклоненное';
$app_list_strings['fintr_moneyout_status_dom']['Duplicate'] = 'Дублировать';
$app_list_strings['fintr_moneyout_priority_dom']['P1'] = 'Высокий';
$app_list_strings['fintr_moneyout_priority_dom']['P2'] = 'Средний';
$app_list_strings['fintr_moneyout_priority_dom']['P3'] = 'Низкий';
$app_list_strings['fintr_moneyout_resolution_dom'][''] = '';
$app_list_strings['fintr_moneyout_resolution_dom']['Accepted'] = 'Принято';
$app_list_strings['fintr_moneyout_resolution_dom']['Duplicate'] = 'Дублировать';
$app_list_strings['fintr_moneyout_resolution_dom']['Closed'] = 'Закрытое';
$app_list_strings['fintr_moneyout_resolution_dom']['Out of Date'] = 'Устарело';
$app_list_strings['fintr_moneyout_resolution_dom']['Invalid'] = 'Недействительно';
$app_list_strings['fintr_moneyout_resolution_dom']['petrol'] = 'Бензин';
$app_list_strings['fintr_moneyout_resolution_dom']['Products'] = 'Товары';
$app_list_strings['fintr_moneyout_resolution_dom']['Materials'] = 'Материалы';
$app_list_strings['fintr_moneyout_resolution_dom']['taxes'] = '____НАЛОГИ____';
$app_list_strings['fintr_moneyout_resolution_dom']['CellPhones'] = 'Сотовые телефоны';
$app_list_strings['fintr_moneyout_resolution_dom']['Salary'] = 'Зарплата';
$app_list_strings['fintr_moneyout_resolution_dom']['Rent'] = 'Арендная плата';
$app_list_strings['fintr_moneyout_resolution_dom']['Phone'] = 'Телефон';
$app_list_strings['fintr_moneyout_resolution_dom']['Internet'] = 'Интернет';
$app_list_strings['fintr_moneyout_resolution_dom']['entertainment'] = 'Представительские расходы';
$app_list_strings['fintr_moneyout_resolution_dom']['transport'] = 'Транспортные расходы';
$app_list_strings['fintr_moneyout_resolution_dom']['taxi'] = 'Такси';
$app_list_strings['fintr_moneyout_resolution_dom']['postage'] = 'Почтовые расходы';
$app_list_strings['fintr_moneyout_resolution_dom']['fixedassets'] = 'Основные средства';
$app_list_strings['fintr_moneyout_resolution_dom']['Tools'] = 'Инструменты';
$app_list_strings['fintr_moneyout_resolution_dom']['Stationery'] = 'Канцтовары';
$app_list_strings['fintr_moneyout_resolution_dom']['designestimates'] = 'Проектно-сметная документация';
$app_list_strings['fintr_moneyout_resolution_dom']['Bank'] = '[Банковские услуги';
$app_list_strings['fintr_moneyout_resolution_dom']['Other'] = 'Прочие';
$app_list_strings['fintr_moneyout_resolution_dom']['Ticket'] = 'Проезд';
$app_list_strings['fintr_moneyout_resolution_dom']['start'] = '_Входящий остаток_';
$app_list_strings['fintr_moneyout_resolution_dom']['Advert'] = 'Реклама';
$app_list_strings['fintr_moneyout_resolution_dom']['BusinesTrip'] = 'Командировочные';
$app_list_strings['fintr_moneyout_resolution_dom']['needs'] = 'Собственные нужды';
$app_list_strings['fintr_moneyout_resolution_dom']['subcontract'] = 'Субподрядные';
$app_list_strings['fintr_towarehouse_type_dom']['Administration'] = 'Ведение';
$app_list_strings['fintr_towarehouse_type_dom']['Product'] = 'Результат';
$app_list_strings['fintr_towarehouse_type_dom']['User'] = 'Клиентское';
$app_list_strings['fintr_towarehouse_status_dom']['New'] = 'Новое';
$app_list_strings['fintr_towarehouse_status_dom']['Assigned'] = 'Назначенное';
$app_list_strings['fintr_towarehouse_status_dom']['Closed'] = 'Закрытое';
$app_list_strings['fintr_towarehouse_status_dom']['Pending Input'] = 'Ожидание решения';
$app_list_strings['fintr_towarehouse_status_dom']['Rejected'] = 'Отклоненное';
$app_list_strings['fintr_towarehouse_status_dom']['Duplicate'] = 'Дублировать';
$app_list_strings['fintr_towarehouse_priority_dom']['P1'] = 'Высокий';
$app_list_strings['fintr_towarehouse_priority_dom']['P2'] = 'Средний';
$app_list_strings['fintr_towarehouse_priority_dom']['P3'] = 'Низкий';
$app_list_strings['fintr_towarehouse_resolution_dom'][''] = '';
$app_list_strings['fintr_towarehouse_resolution_dom']['Accepted'] = 'Принято';
$app_list_strings['fintr_towarehouse_resolution_dom']['Duplicate'] = 'Дублировать';
$app_list_strings['fintr_towarehouse_resolution_dom']['Closed'] = 'Закрытое';
$app_list_strings['fintr_towarehouse_resolution_dom']['Out of Date'] = 'Устарело';
$app_list_strings['fintr_towarehouse_resolution_dom']['Invalid'] = 'Недействительно';
$app_list_strings['fintr_fromwarehouse_type_dom']['Administration'] = 'Ведение';
$app_list_strings['fintr_fromwarehouse_type_dom']['Product'] = 'Результат';
$app_list_strings['fintr_fromwarehouse_type_dom']['User'] = 'Клиентское';
$app_list_strings['fintr_fromwarehouse_status_dom']['New'] = 'Новое';
$app_list_strings['fintr_fromwarehouse_status_dom']['Assigned'] = 'Назначенное';
$app_list_strings['fintr_fromwarehouse_status_dom']['Closed'] = 'Закрытое';
$app_list_strings['fintr_fromwarehouse_status_dom']['Pending Input'] = 'Ожидание решения';
$app_list_strings['fintr_fromwarehouse_status_dom']['Rejected'] = 'Отклоненное';
$app_list_strings['fintr_fromwarehouse_status_dom']['Duplicate'] = 'Дублировать';
$app_list_strings['fintr_fromwarehouse_priority_dom']['P1'] = 'Высокий';
$app_list_strings['fintr_fromwarehouse_priority_dom']['P2'] = 'Средний';
$app_list_strings['fintr_fromwarehouse_priority_dom']['P3'] = 'Низкий';
$app_list_strings['fintr_fromwarehouse_resolution_dom'][''] = '';
$app_list_strings['fintr_fromwarehouse_resolution_dom']['Accepted'] = 'Принято';
$app_list_strings['fintr_fromwarehouse_resolution_dom']['Duplicate'] = 'Дублировать';
$app_list_strings['fintr_fromwarehouse_resolution_dom']['Closed'] = 'Закрытое';
$app_list_strings['fintr_fromwarehouse_resolution_dom']['Out of Date'] = 'Устарело';
$app_list_strings['fintr_fromwarehouse_resolution_dom']['Invalid'] = 'Недействительно';
$app_list_strings['bool_list'][''] = '';
$app_list_strings['bool_list']['yes'] = 'да';
$app_list_strings['bool_list']['no'] = 'нет';
$app_list_strings['fintr_goodsin_type_dom']['Administration'] = 'Ведение';
$app_list_strings['fintr_goodsin_type_dom']['Product'] = 'Результат';
$app_list_strings['fintr_goodsin_type_dom']['User'] = 'Клиентское';
$app_list_strings['fintr_goodsin_status_dom']['New'] = 'Новое';
$app_list_strings['fintr_goodsin_status_dom']['Assigned'] = 'Назначенное';
$app_list_strings['fintr_goodsin_status_dom']['Closed'] = 'Закрытое';
$app_list_strings['fintr_goodsin_status_dom']['Pending Input'] = 'Ожидание решения';
$app_list_strings['fintr_goodsin_status_dom']['Rejected'] = 'Отклоненное';
$app_list_strings['fintr_goodsin_status_dom']['Duplicate'] = 'Дублировать';
$app_list_strings['fintr_goodsin_priority_dom']['P1'] = 'Высокий';
$app_list_strings['fintr_goodsin_priority_dom']['P2'] = 'Средний';
$app_list_strings['fintr_goodsin_priority_dom']['P3'] = 'Низкий';
$app_list_strings['fintr_goodsin_resolution_dom'][''] = '';
$app_list_strings['fintr_goodsin_resolution_dom']['Accepted'] = 'Принято';
$app_list_strings['fintr_goodsin_resolution_dom']['Duplicate'] = 'Дублировать';
$app_list_strings['fintr_goodsin_resolution_dom']['Closed'] = 'Закрытое';
$app_list_strings['fintr_goodsin_resolution_dom']['Out of Date'] = 'Устарело';
$app_list_strings['fintr_goodsin_resolution_dom']['Invalid'] = 'Недействительно';
$app_list_strings['fintr_goodsout_type_dom']['Administration'] = 'Ведение';
$app_list_strings['fintr_goodsout_type_dom']['Product'] = 'Результат';
$app_list_strings['fintr_goodsout_type_dom']['User'] = 'Клиентское';
$app_list_strings['fintr_goodsout_status_dom']['New'] = 'Новое';
$app_list_strings['fintr_goodsout_status_dom']['Assigned'] = 'Назначенное';
$app_list_strings['fintr_goodsout_status_dom']['Closed'] = 'Закрытое';
$app_list_strings['fintr_goodsout_status_dom']['Pending Input'] = 'Ожидание решения';
$app_list_strings['fintr_goodsout_status_dom']['Rejected'] = 'Отклоненное';
$app_list_strings['fintr_goodsout_status_dom']['Duplicate'] = 'Дублировать';
$app_list_strings['fintr_goodsout_priority_dom']['P1'] = 'Высокий';
$app_list_strings['fintr_goodsout_priority_dom']['P2'] = 'Средний';
$app_list_strings['fintr_goodsout_priority_dom']['P3'] = 'Низкий';
$app_list_strings['fintr_goodsout_resolution_dom'][''] = '';
$app_list_strings['fintr_goodsout_resolution_dom']['Accepted'] = 'Принято';
$app_list_strings['fintr_goodsout_resolution_dom']['Duplicate'] = 'Дублировать';
$app_list_strings['fintr_goodsout_resolution_dom']['Closed'] = 'Закрытое';
$app_list_strings['fintr_goodsout_resolution_dom']['Out of Date'] = 'Устарело';
$app_list_strings['fintr_goodsout_resolution_dom']['Invalid'] = 'Недействительно';
$app_list_strings['money_in_via_list']['cash'] = 'Наличными';
$app_list_strings['money_in_via_list'][''] = '';
$app_list_strings['money_in_via_list']['bank_connect'] = 'Через р/с CONNECT';
$app_list_strings['money_in_via_list']['bank_connect_plus'] = 'Через р/с CONNECT PLUS';
$app_list_strings['money_in_via_list']['bank_ib'] = 'Через р/с ИП';
$app_list_strings['money_in_via_list']['bank_other'] = 'Через р/с других...';
$app_list_strings['fintr_cashin_type_dom']['Administration'] = 'Ведение';
$app_list_strings['fintr_cashin_type_dom']['Product'] = 'Результат';
$app_list_strings['fintr_cashin_type_dom']['User'] = 'Клиентское';
$app_list_strings['fintr_cashin_type_dom'][''] = '';
$app_list_strings['fintr_cashin_type_dom']['cashback'] = 'Возврат от подотчётника';
$app_list_strings['fintr_cashin_type_dom']['MoneyIn'] = 'Оплата покупателей';
$app_list_strings['fintr_cashin_type_dom']['other'] = 'Прочие';
$app_list_strings['fintr_cashin_status_dom']['New'] = 'Новое';
$app_list_strings['fintr_cashin_status_dom']['Assigned'] = 'Назначенное';
$app_list_strings['fintr_cashin_status_dom']['Closed'] = 'Закрытое';
$app_list_strings['fintr_cashin_status_dom']['Pending Input'] = 'Ожидание решения';
$app_list_strings['fintr_cashin_status_dom']['Rejected'] = 'Отклоненное';
$app_list_strings['fintr_cashin_status_dom']['Duplicate'] = 'Дублировать';
$app_list_strings['fintr_cashin_priority_dom']['P1'] = 'Высокий';
$app_list_strings['fintr_cashin_priority_dom']['P2'] = 'Средний';
$app_list_strings['fintr_cashin_priority_dom']['P3'] = 'Низкий';
$app_list_strings['fintr_cashin_resolution_dom'][''] = '';
$app_list_strings['fintr_cashin_resolution_dom']['Accepted'] = 'Принято';
$app_list_strings['fintr_cashin_resolution_dom']['Duplicate'] = 'Дублировать';
$app_list_strings['fintr_cashin_resolution_dom']['Closed'] = 'Закрытое';
$app_list_strings['fintr_cashin_resolution_dom']['Out of Date'] = 'Устарело';
$app_list_strings['fintr_cashin_resolution_dom']['Invalid'] = 'Недействительно';
$app_list_strings['fintr_cashout_type_dom']['Administration'] = 'Ведение';
$app_list_strings['fintr_cashout_type_dom']['Product'] = 'Результат';
$app_list_strings['fintr_cashout_type_dom']['User'] = 'Клиентское';
$app_list_strings['fintr_cashout_status_dom']['New'] = 'Новое';
$app_list_strings['fintr_cashout_status_dom']['Assigned'] = 'Назначенное';
$app_list_strings['fintr_cashout_status_dom']['Closed'] = 'Закрытое';
$app_list_strings['fintr_cashout_status_dom']['Pending Input'] = 'Ожидание решения';
$app_list_strings['fintr_cashout_status_dom']['Rejected'] = 'Отклоненное';
$app_list_strings['fintr_cashout_status_dom']['Duplicate'] = 'Дублировать';
$app_list_strings['fintr_cashout_priority_dom']['P1'] = 'Высокий';
$app_list_strings['fintr_cashout_priority_dom']['P2'] = 'Средний';
$app_list_strings['fintr_cashout_priority_dom']['P3'] = 'Низкий';
$app_list_strings['fintr_cashout_resolution_dom'][''] = '';
$app_list_strings['fintr_cashout_resolution_dom']['Accepted'] = 'Принято';
$app_list_strings['fintr_cashout_resolution_dom']['Duplicate'] = 'Дублировать';
$app_list_strings['fintr_cashout_resolution_dom']['Closed'] = 'Закрытое';
$app_list_strings['fintr_cashout_resolution_dom']['Out of Date'] = 'Устарело';
$app_list_strings['fintr_cashout_resolution_dom']['Invalid'] = 'Недействительно';
$app_list_strings['fintr_bankin_type_dom']['Administration'] = 'Ведение';
$app_list_strings['fintr_bankin_type_dom']['Product'] = 'Результат';
$app_list_strings['fintr_bankin_type_dom']['User'] = 'Клиентское';
$app_list_strings['fintr_bankin_status_dom']['New'] = 'Новое';
$app_list_strings['fintr_bankin_status_dom']['Assigned'] = 'Назначенное';
$app_list_strings['fintr_bankin_status_dom']['Closed'] = 'Закрытое';
$app_list_strings['fintr_bankin_status_dom']['Pending Input'] = 'Ожидание решения';
$app_list_strings['fintr_bankin_status_dom']['Rejected'] = 'Отклоненное';
$app_list_strings['fintr_bankin_status_dom']['Duplicate'] = 'Дублировать';
$app_list_strings['fintr_bankin_priority_dom']['P1'] = 'Высокий';
$app_list_strings['fintr_bankin_priority_dom']['P2'] = 'Средний';
$app_list_strings['fintr_bankin_priority_dom']['P3'] = 'Низкий';
$app_list_strings['fintr_bankin_resolution_dom'][''] = '';
$app_list_strings['fintr_bankin_resolution_dom']['Accepted'] = 'Принято';
$app_list_strings['fintr_bankin_resolution_dom']['Duplicate'] = 'Дублировать';
$app_list_strings['fintr_bankin_resolution_dom']['Closed'] = 'Закрытое';
$app_list_strings['fintr_bankin_resolution_dom']['Out of Date'] = 'Устарело';
$app_list_strings['fintr_bankin_resolution_dom']['Invalid'] = 'Недействительно';
$app_list_strings['fintr_bankout_type_dom']['Administration'] = 'Ведение';
$app_list_strings['fintr_bankout_type_dom']['Product'] = 'Результат';
$app_list_strings['fintr_bankout_type_dom']['User'] = 'Клиентское';
$app_list_strings['fintr_bankout_status_dom']['New'] = 'Новое';
$app_list_strings['fintr_bankout_status_dom']['Assigned'] = 'Назначенное';
$app_list_strings['fintr_bankout_status_dom']['Closed'] = 'Закрытое';
$app_list_strings['fintr_bankout_status_dom']['Pending Input'] = 'Ожидание решения';
$app_list_strings['fintr_bankout_status_dom']['Rejected'] = 'Отклоненное';
$app_list_strings['fintr_bankout_status_dom']['Duplicate'] = 'Дублировать';
$app_list_strings['fintr_bankout_priority_dom']['P1'] = 'Высокий';
$app_list_strings['fintr_bankout_priority_dom']['P2'] = 'Средний';
$app_list_strings['fintr_bankout_priority_dom']['P3'] = 'Низкий';
$app_list_strings['fintr_bankout_resolution_dom'][''] = '';
$app_list_strings['fintr_bankout_resolution_dom']['Accepted'] = 'Принято';
$app_list_strings['fintr_bankout_resolution_dom']['Duplicate'] = 'Дублировать';
$app_list_strings['fintr_bankout_resolution_dom']['Closed'] = 'Закрытое';
$app_list_strings['fintr_bankout_resolution_dom']['Out of Date'] = 'Устарело';
$app_list_strings['fintr_bankout_resolution_dom']['Invalid'] = 'Недействительно';
$app_list_strings['CashIn_status_list']['new'] = 'new';
$app_list_strings['CashIn_status_list']['closed'] = 'closed';
$app_list_strings['fintr_cashin_type_list'][''] = '';
$app_list_strings['fintr_cashin_type_list']['cashback'] = 'Возврат от подотчётника';
$app_list_strings['fintr_cashin_type_list']['MoneyIn'] = 'Оплата покупателей';
$app_list_strings['fintr_cashin_type_list']['other'] = 'Прочие';
