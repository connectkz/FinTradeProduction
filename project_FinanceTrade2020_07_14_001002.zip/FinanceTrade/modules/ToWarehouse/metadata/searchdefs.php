<?php
$module_name = 'FinTr_ToWarehouse';
$_object_name = 'fintr_towarehouse';
$searchdefs [$module_name] = 
array (
  'layout' => 
  array (
    'basic_search' => 
    array (
      'name' => 
      array (
        'name' => 'name',
        'default' => true,
        'width' => '10%',
      ),
      'fintr_brand_fintr_towarehouse_name' => 
      array (
        'type' => 'relate',
        'link' => true,
        'label' => 'LBL_FINTR_BRAND_FINTR_TOWAREHOUSE_FROM_FINTR_BRAND_TITLE',
        'id' => 'FINTR_BRAND_FINTR_TOWAREHOUSEFINTR_BRAND_IDA',
        'width' => '10%',
        'default' => true,
        'name' => 'fintr_brand_fintr_towarehouse_name',
      ),
      'fintr_type_fintr_towarehouse_name' => 
      array (
        'type' => 'relate',
        'link' => true,
        'label' => 'LBL_FINTR_TYPE_FINTR_TOWAREHOUSE_FROM_FINTR_TYPE_TITLE',
        'id' => 'FINTR_TYPE_FINTR_TOWAREHOUSEFINTR_TYPE_IDA',
        'width' => '10%',
        'default' => true,
        'name' => 'fintr_type_fintr_towarehouse_name',
      ),
    ),
    'advanced_search' => 
    array (
      'name' => 
      array (
        'name' => 'name',
        'default' => true,
        'width' => '10%',
      ),
      'fintr_brand_fintr_towarehouse_name' => 
      array (
        'type' => 'relate',
        'link' => true,
        'label' => 'LBL_FINTR_BRAND_FINTR_TOWAREHOUSE_FROM_FINTR_BRAND_TITLE',
        'width' => '10%',
        'default' => true,
        'id' => 'FINTR_BRAND_FINTR_TOWAREHOUSEFINTR_BRAND_IDA',
        'name' => 'fintr_brand_fintr_towarehouse_name',
      ),
      'fintr_type_fintr_towarehouse_name' => 
      array (
        'type' => 'relate',
        'link' => true,
        'label' => 'LBL_FINTR_TYPE_FINTR_TOWAREHOUSE_FROM_FINTR_TYPE_TITLE',
        'width' => '10%',
        'default' => true,
        'id' => 'FINTR_TYPE_FINTR_TOWAREHOUSEFINTR_TYPE_IDA',
        'name' => 'fintr_type_fintr_towarehouse_name',
      ),
      'serial_number' => 
      array (
        'type' => 'varchar',
        'label' => 'LBL_SERIAL_NUMBER',
        'width' => '10%',
        'default' => true,
        'name' => 'serial_number',
      ),
      'fintr_towarehouse_number' => 
      array (
        'name' => 'fintr_towarehouse_number',
        'default' => true,
        'width' => '10%',
      ),
      'assigned_user_id' => 
      array (
        'name' => 'assigned_user_id',
        'type' => 'enum',
        'label' => 'LBL_ASSIGNED_TO',
        'function' => 
        array (
          'name' => 'get_user_array',
          'params' => 
          array (
            0 => false,
          ),
        ),
        'default' => true,
        'width' => '10%',
      ),
      'date_in' => 
      array (
        'type' => 'date',
        'label' => 'LBL_DATE_IN',
        'width' => '10%',
        'default' => true,
        'name' => 'date_in',
      ),
    ),
  ),
  'templateMeta' => 
  array (
    'maxColumns' => '3',
    'maxColumnsBasic' => '4',
    'widths' => 
    array (
      'label' => '10',
      'field' => '30',
    ),
  ),
);
?>
