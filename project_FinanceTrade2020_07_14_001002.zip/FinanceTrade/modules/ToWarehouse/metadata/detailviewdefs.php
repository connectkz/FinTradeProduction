<?php
$module_name = 'FinTr_ToWarehouse';
$_object_name = 'fintr_towarehouse';
$viewdefs [$module_name] = 
array (
  'DetailView' => 
  array (
    'templateMeta' => 
    array (
      'form' => 
      array (
        'buttons' => 
        array (
          0 => 'EDIT',
          1 => 'DUPLICATE',
          2 => 'DELETE',
          3 => 'FIND_DUPLICATES',
        ),
      ),
      'maxColumns' => '2',
      'widths' => 
      array (
        0 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
        1 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
      ),
      'useTabs' => true,
      'tabDefs' => 
      array (
        'DEFAULT' => 
        array (
          'newTab' => true,
          'panelDefault' => 'expanded',
        ),
        'LBL_EDITVIEW_PANEL1' => 
        array (
          'newTab' => true,
          'panelDefault' => 'expanded',
        ),
      ),
      'syncDetailEditViews' => true,
    ),
    'panels' => 
    array (
      'default' => 
      array (
        0 => 
        array (
          0 => 
          array (
            'name' => 'fintr_model_fintr_towarehouse_name',
          ),
          1 => 
          array (
            'name' => 'serial_number',
            'label' => 'LBL_SERIAL_NUMBER',
          ),
        ),
        1 => 
        array (
          0 => 
          array (
            'name' => 'valuein',
            'label' => 'LBL_VALUEIN',
          ),
          1 => 
          array (
            'name' => 'add_to_storageunit',
            'label' => 'LBL_ADD_TO_STORAGEUNIT',
          ),
        ),
        2 => 
        array (
          0 => 
          array (
            'name' => 'place',
            'label' => 'LBL_PLACE',
          ),
          1 => 
          array (
            'name' => 'date_entered',
            'comment' => 'Date record created',
            'label' => 'LBL_DATE_ENTERED',
          ),
        ),
        3 => 
        array (
          0 => 
          array (
            'name' => 'assigned_user_name',
            'label' => 'LBL_ASSIGNED_TO_NAME',
          ),
          1 => 
          array (
            'name' => 'date_in',
            'label' => 'LBL_DATE_IN',
          ),
        ),
      ),
      'lbl_editview_panel1' => 
      array (
        0 => 
        array (
          0 => 
          array (
            'name' => 'fintr_type_fintr_towarehouse_name',
          ),
          1 => 
          array (
            'name' => 'fintr_brand_fintr_towarehouse_name',
          ),
        ),
        1 => 
        array (
          0 => 'fintr_towarehouse_number',
          1 => 
          array (
            'name' => 'fintr_storageunit_fintr_towarehouse_name',
          ),
        ),
        2 => 
        array (
          0 => 'description',
        ),
      ),
    ),
  ),
);
?>
