<?php
$module_name = 'FinTr_ToWarehouse';
$_object_name = 'fintr_towarehouse';
$viewdefs [$module_name] = 
array (
  'QuickCreate' => 
  array (
    'templateMeta' => 
    array (
      'maxColumns' => '2',
      'widths' => 
      array (
        0 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
        1 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
      ),
      'useTabs' => false,
      'tabDefs' => 
      array (
        'DEFAULT' => 
        array (
          'newTab' => false,
          'panelDefault' => 'expanded',
        ),
      ),
    ),
    'panels' => 
    array (
      'default' => 
      array (
        0 => 
        array (
          0 => 
          array (
            'name' => 'fintr_model_fintr_towarehouse_name',
            'label' => 'LBL_FINTR_MODEL_FINTR_TOWAREHOUSE_FROM_FINTR_MODEL_TITLE',
          ),
          1 => 
          array (
            'name' => 'serial_number',
            'label' => 'LBL_SERIAL_NUMBER',
          ),
        ),
        1 => 
        array (
          0 => 
          array (
            'name' => 'valuein',
            'label' => 'LBL_VALUEIN',
          ),
          1 => 
          array (
            'name' => 'add_to_storageunit',
            'label' => 'LBL_ADD_TO_STORAGEUNIT',
          ),
        ),
      ),
    ),
  ),
);
?>
