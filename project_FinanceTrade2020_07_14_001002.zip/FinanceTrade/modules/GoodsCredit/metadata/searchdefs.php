<?php
$module_name = 'FinTr_GoodsCredit';
$searchdefs [$module_name] = 
array (
  'layout' => 
  array (
    'basic_search' => 
    array (
      'fintr_model_fintr_goodscredit_name' => 
      array (
        'type' => 'relate',
        'link' => true,
        'label' => 'LBL_FINTR_MODEL_FINTR_GOODSCREDIT_FROM_FINTR_MODEL_TITLE',
        'id' => 'FINTR_MODEL_FINTR_GOODSCREDITFINTR_MODEL_IDA',
        'width' => '10%',
        'default' => true,
        'name' => 'fintr_model_fintr_goodscredit_name',
      ),
      'assigned_user_id' => 
      array (
        'name' => 'assigned_user_id',
        'label' => 'LBL_ASSIGNED_TO',
        'type' => 'enum',
        'function' => 
        array (
          'name' => 'get_user_array',
          'params' => 
          array (
            0 => false,
          ),
        ),
        'width' => '10%',
        'default' => true,
      ),
      'date_entered' => 
      array (
        'type' => 'datetime',
        'label' => 'LBL_DATE_ENTERED',
        'width' => '10%',
        'default' => true,
        'name' => 'date_entered',
      ),
    ),
    'advanced_search' => 
    array (
      'fintr_model_fintr_goodscredit_name' => 
      array (
        'type' => 'relate',
        'link' => true,
        'label' => 'LBL_FINTR_MODEL_FINTR_GOODSCREDIT_FROM_FINTR_MODEL_TITLE',
        'width' => '10%',
        'default' => true,
        'id' => 'FINTR_MODEL_FINTR_GOODSCREDITFINTR_MODEL_IDA',
        'name' => 'fintr_model_fintr_goodscredit_name',
      ),
      'assigned_user_id' => 
      array (
        'name' => 'assigned_user_id',
        'label' => 'LBL_ASSIGNED_TO',
        'type' => 'enum',
        'function' => 
        array (
          'name' => 'get_user_array',
          'params' => 
          array (
            0 => false,
          ),
        ),
        'default' => true,
        'width' => '10%',
      ),
      'date_entered' => 
      array (
        'type' => 'datetime',
        'label' => 'LBL_DATE_ENTERED',
        'width' => '10%',
        'default' => true,
        'name' => 'date_entered',
      ),
      'value' => 
      array (
        'type' => 'decimal',
        'label' => 'LBL_VALUE',
        'width' => '10%',
        'default' => true,
        'name' => 'value',
      ),
    ),
  ),
  'templateMeta' => 
  array (
    'maxColumns' => '3',
    'maxColumnsBasic' => '4',
    'widths' => 
    array (
      'label' => '10',
      'field' => '30',
    ),
  ),
);
?>
