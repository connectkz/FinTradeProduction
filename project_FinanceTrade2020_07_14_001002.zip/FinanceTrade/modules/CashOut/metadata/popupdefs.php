<?php
$popupMeta = array (
    'moduleMain' => 'FinTr_CashOut',
    'varName' => 'FinTr_CashOut',
    'orderBy' => 'fintr_cashout.name',
    'whereClauses' => array (
  'fintr_cashout_number' => 'fintr_cashout.fintr_cashout_number',
  'currency' => 'fintr_cashout.currency',
  'date_entered' => 'fintr_cashout.date_entered',
  'assigned_user_name' => 'fintr_cashout.assigned_user_name',
),
    'searchInputs' => array (
  0 => 'fintr_cashout_number',
  4 => 'currency',
  5 => 'date_entered',
  6 => 'assigned_user_name',
),
    'searchdefs' => array (
  'fintr_cashout_number' => 
  array (
    'type' => 'int',
    'studio' => 
    array (
      'quickcreate' => false,
    ),
    'label' => 'LBL_NUMBER',
    'width' => '10%',
    'name' => 'fintr_cashout_number',
  ),
  'currency' => 
  array (
    'type' => 'currency',
    'label' => 'LBL_CURRENCY',
    'currency_format' => true,
    'width' => '10%',
    'name' => 'currency',
  ),
  'date_entered' => 
  array (
    'type' => 'datetime',
    'label' => 'LBL_DATE_ENTERED',
    'width' => '10%',
    'name' => 'date_entered',
  ),
  'assigned_user_name' => 
  array (
    'link' => true,
    'type' => 'relate',
    'label' => 'LBL_ASSIGNED_TO_NAME',
    'id' => 'ASSIGNED_USER_ID',
    'width' => '10%',
    'name' => 'assigned_user_name',
  ),
),
    'listviewdefs' => array (
  'FINTR_CASHOUT_NUMBER' => 
  array (
    'type' => 'int',
    'studio' => 
    array (
      'quickcreate' => false,
    ),
    'label' => 'LBL_NUMBER',
    'width' => '10%',
    'default' => true,
  ),
  'CURRENCY' => 
  array (
    'type' => 'currency',
    'label' => 'LBL_CURRENCY',
    'currency_format' => true,
    'width' => '10%',
    'default' => true,
  ),
  'ASSIGNED_USER_NAME' => 
  array (
    'link' => true,
    'type' => 'relate',
    'label' => 'LBL_ASSIGNED_TO_NAME',
    'id' => 'ASSIGNED_USER_ID',
    'width' => '10%',
    'default' => true,
  ),
  'DATE_ENTERED' => 
  array (
    'type' => 'datetime',
    'label' => 'LBL_DATE_ENTERED',
    'width' => '10%',
    'default' => true,
  ),
),
);
