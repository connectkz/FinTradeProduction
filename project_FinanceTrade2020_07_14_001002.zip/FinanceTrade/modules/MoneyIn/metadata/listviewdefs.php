<?php
$module_name = 'FinTr_MoneyIn';
$OBJECT_NAME = 'FINTR_MONEYIN';
$listViewDefs [$module_name] = 
array (
  'FINTR_MONEYIN_NUMBER' => 
  array (
    'width' => '5%',
    'label' => 'LBL_NUMBER',
    'link' => true,
    'default' => true,
  ),
  'DATE_ENTERED' => 
  array (
    'type' => 'datetime',
    'label' => 'LBL_DATE_ENTERED',
    'width' => '10%',
    'default' => true,
  ),
  'BANKING' => 
  array (
    'type' => 'date',
    'label' => 'LBL_BANKING',
    'width' => '10%',
    'default' => true,
  ),
  'MONEY_IN_VIA' => 
  array (
    'type' => 'enum',
    'default' => true,
    'studio' => 'visible',
    'label' => 'LBL_MONEY_IN_VIA',
    'width' => '10%',
  ),
  'NAME' => 
  array (
    'width' => '32%',
    'label' => 'LBL_SUBJECT',
    'default' => true,
    'link' => true,
  ),
  'MONEY_IN' => 
  array (
    'type' => 'currency',
    'label' => 'LBL_MONEY_IN',
    'currency_format' => true,
    'width' => '10%',
    'default' => true,
  ),
  'FINTR_MONEYIN_OPPORTUNITIES_NAME' => 
  array (
    'type' => 'relate',
    'link' => true,
    'label' => 'LBL_FINTR_MONEYIN_OPPORTUNITIES_FROM_OPPORTUNITIES_TITLE',
    'id' => 'FINTR_MONEYIN_OPPORTUNITIESOPPORTUNITIES_IDA',
    'width' => '10%',
    'default' => true,
  ),
  'ASSIGNED_USER_NAME' => 
  array (
    'width' => '9%',
    'label' => 'LBL_ASSIGNED_USER',
    'module' => 'Employees',
    'id' => 'ASSIGNED_USER_ID',
    'default' => true,
  ),
  'BLACKCASH' => 
  array (
    'type' => 'bool',
    'default' => true,
    'label' => 'LBL_BLACKCASH',
    'width' => '10%',
  ),
);
?>
