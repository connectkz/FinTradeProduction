<?php
$module_name = 'FinTr_MoneyIn';
$_object_name = 'fintr_moneyin';
$searchdefs [$module_name] = 
array (
  'layout' => 
  array (
    'basic_search' => 
    array (
      'money_in_via' => 
      array (
        'type' => 'enum',
        'default' => true,
        'studio' => 'visible',
        'label' => 'LBL_MONEY_IN_VIA',
        'width' => '10%',
        'name' => 'money_in_via',
      ),
      'money_in' => 
      array (
        'type' => 'currency',
        'label' => 'LBL_MONEY_IN',
        'currency_format' => true,
        'width' => '10%',
        'default' => true,
        'name' => 'money_in',
      ),
      'fintr_moneyin_number' => 
      array (
        'type' => 'int',
        'studio' => 
        array (
          'quickcreate' => false,
        ),
        'label' => 'LBL_NUMBER',
        'width' => '10%',
        'default' => true,
        'name' => 'fintr_moneyin_number',
      ),
    ),
    'advanced_search' => 
    array (
      'money_in_via' => 
      array (
        'type' => 'enum',
        'default' => true,
        'studio' => 'visible',
        'label' => 'LBL_MONEY_IN_VIA',
        'width' => '10%',
        'name' => 'money_in_via',
      ),
      'money_in' => 
      array (
        'type' => 'currency',
        'label' => 'LBL_MONEY_IN',
        'currency_format' => true,
        'width' => '10%',
        'default' => true,
        'name' => 'money_in',
      ),
      'fintr_moneyin_number' => 
      array (
        'name' => 'fintr_moneyin_number',
        'default' => true,
        'width' => '10%',
      ),
      'banking' => 
      array (
        'type' => 'date',
        'label' => 'LBL_BANKING',
        'width' => '10%',
        'default' => true,
        'name' => 'banking',
      ),
      'name' => 
      array (
        'name' => 'name',
        'default' => true,
        'width' => '10%',
      ),
      'fintr_moneyin_opportunities_name' => 
      array (
        'type' => 'relate',
        'link' => true,
        'label' => 'LBL_FINTR_MONEYIN_OPPORTUNITIES_FROM_OPPORTUNITIES_TITLE',
        'id' => 'FINTR_MONEYIN_OPPORTUNITIESOPPORTUNITIES_IDA',
        'width' => '10%',
        'default' => true,
        'name' => 'fintr_moneyin_opportunities_name',
      ),
      'blackcash' => 
      array (
        'type' => 'bool',
        'default' => true,
        'label' => 'LBL_BLACKCASH',
        'width' => '10%',
        'name' => 'blackcash',
      ),
    ),
  ),
  'templateMeta' => 
  array (
    'maxColumns' => '3',
    'maxColumnsBasic' => '4',
    'widths' => 
    array (
      'label' => '10',
      'field' => '30',
    ),
  ),
);
?>
