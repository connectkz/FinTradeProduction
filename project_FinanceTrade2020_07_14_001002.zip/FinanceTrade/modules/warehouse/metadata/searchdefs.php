<?php
$module_name = 'FinTr_warehouse';
$searchdefs [$module_name] = 
array (
  'layout' => 
  array (
    'basic_search' => 
    array (
      'name' => 
      array (
        'name' => 'name',
        'default' => true,
        'width' => '10%',
      ),
      'fintr_type_fintr_warehouse_name' => 
      array (
        'type' => 'relate',
        'link' => true,
        'label' => 'LBL_FINTR_TYPE_FINTR_WAREHOUSE_FROM_FINTR_TYPE_TITLE',
        'id' => 'FINTR_TYPE_FINTR_WAREHOUSEFINTR_TYPE_IDA',
        'width' => '10%',
        'default' => true,
        'name' => 'fintr_type_fintr_warehouse_name',
      ),
      'fintr_brand_fintr_warehouse_name' => 
      array (
        'type' => 'relate',
        'link' => true,
        'label' => 'LBL_FINTR_BRAND_FINTR_WAREHOUSE_FROM_FINTR_BRAND_TITLE',
        'id' => 'FINTR_BRAND_FINTR_WAREHOUSEFINTR_BRAND_IDA',
        'width' => '10%',
        'default' => true,
        'name' => 'fintr_brand_fintr_warehouse_name',
      ),
    ),
    'advanced_search' => 
    array (
      'name' => 
      array (
        'name' => 'name',
        'default' => true,
        'width' => '10%',
      ),
      'fintr_type_fintr_warehouse_name' => 
      array (
        'type' => 'relate',
        'link' => true,
        'label' => 'LBL_FINTR_TYPE_FINTR_WAREHOUSE_FROM_FINTR_TYPE_TITLE',
        'width' => '10%',
        'default' => true,
        'id' => 'FINTR_TYPE_FINTR_WAREHOUSEFINTR_TYPE_IDA',
        'name' => 'fintr_type_fintr_warehouse_name',
      ),
      'fintr_brand_fintr_warehouse_name' => 
      array (
        'type' => 'relate',
        'link' => true,
        'label' => 'LBL_FINTR_BRAND_FINTR_WAREHOUSE_FROM_FINTR_BRAND_TITLE',
        'width' => '10%',
        'default' => true,
        'id' => 'FINTR_BRAND_FINTR_WAREHOUSEFINTR_BRAND_IDA',
        'name' => 'fintr_brand_fintr_warehouse_name',
      ),
      'with_docu' => 
      array (
        'type' => 'decimal',
        'label' => 'LBL_WITH_DOCU',
        'width' => '10%',
        'default' => true,
        'name' => 'with_docu',
      ),
      'without_docu' => 
      array (
        'type' => 'decimal',
        'label' => 'LBL_WITHOUT_DOCU',
        'width' => '10%',
        'default' => true,
        'name' => 'without_docu',
      ),
    ),
  ),
  'templateMeta' => 
  array (
    'maxColumns' => '3',
    'maxColumnsBasic' => '4',
    'widths' => 
    array (
      'label' => '10',
      'field' => '30',
    ),
  ),
);
?>
