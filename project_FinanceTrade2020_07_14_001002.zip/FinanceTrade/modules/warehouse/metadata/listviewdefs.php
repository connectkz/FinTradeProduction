<?php
$module_name = 'FinTr_warehouse';
$listViewDefs [$module_name] = 
array (
  'NAME' => 
  array (
    'width' => '15%',
    'label' => 'LBL_NAME',
    'default' => true,
    'link' => true,
  ),
  'SUM' => 
  array (
    'type' => 'decimal',
    'label' => 'LBL_SUM',
    'width' => '10%',
    'default' => true,
  ),
  'WITH_DOCU' => 
  array (
    'type' => 'decimal',
    'label' => 'LBL_WITH_DOCU',
    'width' => '10%',
    'default' => true,
  ),
  'WITHOUT_DOCU' => 
  array (
    'type' => 'decimal',
    'label' => 'LBL_WITHOUT_DOCU',
    'width' => '10%',
    'default' => true,
  ),
);
?>
