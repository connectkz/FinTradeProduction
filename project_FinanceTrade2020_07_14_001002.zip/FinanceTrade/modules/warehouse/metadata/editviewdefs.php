<?php
$module_name = 'FinTr_warehouse';
$viewdefs [$module_name] = 
array (
  'EditView' => 
  array (
    'templateMeta' => 
    array (
      'maxColumns' => '2',
      'widths' => 
      array (
        0 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
        1 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
      ),
      'useTabs' => false,
      'tabDefs' => 
      array (
        'DEFAULT' => 
        array (
          'newTab' => false,
          'panelDefault' => 'expanded',
        ),
      ),
      'syncDetailEditViews' => true,
    ),
    'panels' => 
    array (
      'default' => 
      array (
        0 => 
        array (
          0 => 'name',
          1 => 
          array (
            'name' => 'with_docu',
            'label' => 'LBL_WITH_DOCU',
          ),
        ),
        1 => 
        array (
          0 => 
          array (
            'name' => 'sum',
            'label' => 'LBL_SUM',
          ),
          1 => 
          array (
            'name' => 'without_docu',
            'label' => 'LBL_WITHOUT_DOCU',
          ),
        ),
        2 => 
        array (
          0 => 'description',
          1 => 
          array (
            'name' => 'fintr_brand_fintr_warehouse_name',
          ),
        ),
        3 => 
        array (
          0 => 
          array (
            'name' => 'fintr_type_fintr_warehouse_name',
          ),
          1 => 
          array (
            'name' => 'fintr_model_fintr_warehouse_name',
          ),
        ),
      ),
    ),
  ),
);
?>
