<?php
$popupMeta = array (
    'moduleMain' => 'FinTr_warehouse',
    'varName' => 'FinTr_warehouse',
    'orderBy' => 'fintr_warehouse.name',
    'whereClauses' => array (
  'name' => 'fintr_warehouse.name',
),
    'searchInputs' => array (
  1 => 'name',
),
    'searchdefs' => array (
  'name' => 
  array (
    'type' => 'name',
    'link' => true,
    'label' => 'LBL_NAME',
    'width' => '10%',
    'name' => 'name',
  ),
),
    'listviewdefs' => array (
  'NAME' => 
  array (
    'type' => 'name',
    'link' => true,
    'label' => 'LBL_NAME',
    'width' => '10%',
    'default' => true,
    'name' => 'name',
  ),
  'SUM' => 
  array (
    'type' => 'decimal',
    'label' => 'LBL_SUM',
    'width' => '10%',
    'default' => true,
  ),
  'WITH_DOCU' => 
  array (
    'type' => 'decimal',
    'label' => 'LBL_WITH_DOCU',
    'width' => '10%',
    'default' => true,
  ),
  'WITHOUT_DOCU' => 
  array (
    'type' => 'decimal',
    'label' => 'LBL_WITHOUT_DOCU',
    'width' => '10%',
    'default' => true,
  ),
),
);
