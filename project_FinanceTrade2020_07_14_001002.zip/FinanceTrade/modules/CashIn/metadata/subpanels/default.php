<?php
$module_name='FinTr_CashIn';
$subpanel_layout = array (
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'popup_module' => 'FinTr_CashIn',
    ),
  ),
  'where' => '',
  'list_fields' => 
  array (
    'fintr_cashin_number' => 
    array (
      'type' => 'int',
      'studio' => 
      array (
        'quickcreate' => false,
      ),
      'vname' => 'LBL_NUMBER',
      'width' => '10%',
      'default' => true,
    ),
    'name' => 
    array (
      'vname' => 'LBL_SUBJECT',
      'widget_class' => 'SubPanelDetailViewLink',
      'width' => '15%',
      'default' => true,
    ),
    'currency' => 
    array (
      'type' => 'currency',
      'vname' => 'LBL_CURRENCY',
      'currency_format' => true,
      'width' => '10%',
      'default' => true,
    ),
    'date_entered' => 
    array (
      'type' => 'datetime',
      'vname' => 'LBL_DATE_ENTERED',
      'width' => '10%',
      'default' => true,
    ),
    'description' => 
    array (
      'type' => 'text',
      'studio' => 'visible',
      'vname' => 'LBL_DESCRIPTION',
      'sortable' => false,
      'width' => '10%',
      'default' => true,
    ),
    'assigned_user_name' => 
    array (
      'name' => 'assigned_user_name',
      'vname' => 'LBL_ASSIGNED_TO_NAME',
      'widget_class' => 'SubPanelDetailViewLink',
      'target_record_key' => 'assigned_user_id',
      'target_module' => 'Employees',
      'width' => '10%',
      'default' => true,
    ),
    'edit_button' => 
    array (
      'vname' => 'LBL_EDIT_BUTTON',
      'widget_class' => 'SubPanelEditButton',
      'module' => 'FinTr_CashIn',
      'width' => '4%',
      'default' => true,
    ),
    'remove_button' => 
    array (
      'vname' => 'LBL_REMOVE',
      'widget_class' => 'SubPanelRemoveButton',
      'module' => 'FinTr_CashIn',
      'width' => '5%',
      'default' => true,
    ),
  ),
);