<?php
$module_name = 'FinTr_StorageUnit';
$searchdefs [$module_name] = 
array (
  'layout' => 
  array (
    'basic_search' => 
    array (
      'name' => 
      array (
        'name' => 'name',
        'default' => true,
        'width' => '10%',
      ),
      'fintr_type_fintr_storageunit_name' => 
      array (
        'type' => 'relate',
        'link' => true,
        'label' => 'LBL_FINTR_TYPE_FINTR_STORAGEUNIT_FROM_FINTR_TYPE_TITLE',
        'id' => 'FINTR_TYPE_FINTR_STORAGEUNITFINTR_TYPE_IDA',
        'width' => '10%',
        'default' => true,
        'name' => 'fintr_type_fintr_storageunit_name',
      ),
      'fintr_brand_fintr_storageunit_name' => 
      array (
        'type' => 'relate',
        'link' => true,
        'label' => 'LBL_FINTR_BRAND_FINTR_STORAGEUNIT_FROM_FINTR_BRAND_TITLE',
        'id' => 'FINTR_BRAND_FINTR_STORAGEUNITFINTR_BRAND_IDA',
        'width' => '10%',
        'default' => true,
        'name' => 'fintr_brand_fintr_storageunit_name',
      ),
    ),
    'advanced_search' => 
    array (
      'name' => 
      array (
        'name' => 'name',
        'default' => true,
        'width' => '10%',
      ),
      'fintr_type_fintr_storageunit_name' => 
      array (
        'type' => 'relate',
        'link' => true,
        'label' => 'LBL_FINTR_TYPE_FINTR_STORAGEUNIT_FROM_FINTR_TYPE_TITLE',
        'width' => '10%',
        'default' => true,
        'id' => 'FINTR_TYPE_FINTR_STORAGEUNITFINTR_TYPE_IDA',
        'name' => 'fintr_type_fintr_storageunit_name',
      ),
      'fintr_brand_fintr_storageunit_name' => 
      array (
        'type' => 'relate',
        'link' => true,
        'label' => 'LBL_FINTR_BRAND_FINTR_STORAGEUNIT_FROM_FINTR_BRAND_TITLE',
        'width' => '10%',
        'default' => true,
        'id' => 'FINTR_BRAND_FINTR_STORAGEUNITFINTR_BRAND_IDA',
        'name' => 'fintr_brand_fintr_storageunit_name',
      ),
      'serial_number' => 
      array (
        'type' => 'varchar',
        'label' => 'LBL_SERIAL_NUMBER',
        'width' => '10%',
        'default' => true,
        'name' => 'serial_number',
      ),
      'value_in_storageunit' => 
      array (
        'type' => 'decimal',
        'label' => 'LBL_VALUE_IN_STORAGEUNIT',
        'width' => '10%',
        'default' => true,
        'name' => 'value_in_storageunit',
      ),
    ),
  ),
  'templateMeta' => 
  array (
    'maxColumns' => '3',
    'maxColumnsBasic' => '4',
    'widths' => 
    array (
      'label' => '10',
      'field' => '30',
    ),
  ),
);
?>
