<?php
$module_name = 'FinTr_StorageUnit';
$listViewDefs [$module_name] = 
array (
  'NAME' => 
  array (
    'width' => '15%',
    'label' => 'LBL_NAME',
    'default' => true,
    'link' => true,
  ),
  'VALUE_IN_STORAGEUNIT' => 
  array (
    'type' => 'decimal',
    'label' => 'LBL_VALUE_IN_STORAGEUNIT',
    'width' => '10%',
    'default' => true,
  ),
  'PLACE' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_PLACE',
    'width' => '10%',
    'default' => true,
  ),
  'SERIAL_NUMBER' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_SERIAL_NUMBER',
    'width' => '10%',
    'default' => true,
  ),
  'FINTR_BRAND_FINTR_STORAGEUNIT_NAME' => 
  array (
    'type' => 'relate',
    'link' => true,
    'label' => 'LBL_FINTR_BRAND_FINTR_STORAGEUNIT_FROM_FINTR_BRAND_TITLE',
    'id' => 'FINTR_BRAND_FINTR_STORAGEUNITFINTR_BRAND_IDA',
    'width' => '10%',
    'default' => true,
  ),
);
?>
