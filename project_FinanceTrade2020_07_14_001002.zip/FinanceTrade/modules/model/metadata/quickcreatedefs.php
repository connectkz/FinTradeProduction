<?php
$module_name = 'FinTr_model';
$viewdefs [$module_name] = 
array (
  'QuickCreate' => 
  array (
    'templateMeta' => 
    array (
      'maxColumns' => '2',
      'widths' => 
      array (
        0 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
        1 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
      ),
      'useTabs' => false,
      'tabDefs' => 
      array (
        'DEFAULT' => 
        array (
          'newTab' => false,
          'panelDefault' => 'expanded',
        ),
      ),
    ),
    'panels' => 
    array (
      'default' => 
      array (
        0 => 
        array (
          0 => 'name',
          1 => 
          array (
            'name' => 'description',
            'comment' => 'Full text of the note',
            'studio' => 'visible',
            'label' => 'LBL_DESCRIPTION',
          ),
        ),
        1 => 
        array (
          0 => 
          array (
            'name' => 'fintr_brand_fintr_model_name',
            'label' => 'LBL_FINTR_BRAND_FINTR_MODEL_FROM_FINTR_BRAND_TITLE',
          ),
          1 => 
          array (
            'name' => 'fintr_type_fintr_model_name',
            'label' => 'LBL_FINTR_TYPE_FINTR_MODEL_FROM_FINTR_TYPE_TITLE',
          ),
        ),
        2 => 
        array (
          0 => 
          array (
            'name' => 'serialnumber',
            'studio' => 'visible',
            'label' => 'LBL_SERIALNUMBER',
          ),
          1 => 
          array (
            'name' => 'merged',
            'studio' => 'visible',
            'label' => 'LBL_MERGED',
          ),
        ),
      ),
    ),
  ),
);
?>
