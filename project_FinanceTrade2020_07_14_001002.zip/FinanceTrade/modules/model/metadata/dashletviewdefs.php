<?php
$dashletData['FinTr_modelDashlet']['searchFields'] = array (
  'name' => 
  array (
    'default' => '',
  ),
  'fintr_type_fintr_model_name' => 
  array (
    'default' => '',
  ),
  'fintr_brand_fintr_model_name' => 
  array (
    'default' => '',
  ),
  'serialnumber' => 
  array (
    'default' => '',
  ),
  'merged' => 
  array (
    'default' => '',
  ),
);
$dashletData['FinTr_modelDashlet']['columns'] = array (
  'name' => 
  array (
    'width' => '40%',
    'label' => 'LBL_LIST_NAME',
    'link' => true,
    'default' => true,
    'name' => 'name',
  ),
  'fintr_brand_fintr_model_name' => 
  array (
    'type' => 'relate',
    'link' => true,
    'label' => 'LBL_FINTR_BRAND_FINTR_MODEL_FROM_FINTR_BRAND_TITLE',
    'id' => 'FINTR_BRAND_FINTR_MODELFINTR_BRAND_IDA',
    'width' => '10%',
    'default' => true,
  ),
  'fintr_type_fintr_model_name' => 
  array (
    'type' => 'relate',
    'link' => true,
    'label' => 'LBL_FINTR_TYPE_FINTR_MODEL_FROM_FINTR_TYPE_TITLE',
    'id' => 'FINTR_TYPE_FINTR_MODELFINTR_TYPE_IDA',
    'width' => '10%',
    'default' => true,
  ),
  'serialnumber' => 
  array (
    'type' => 'enum',
    'studio' => 'visible',
    'label' => 'LBL_SERIALNUMBER',
    'width' => '10%',
    'default' => true,
  ),
  'merged' => 
  array (
    'type' => 'enum',
    'studio' => 'visible',
    'label' => 'LBL_MERGED',
    'width' => '10%',
    'default' => true,
  ),
  'date_modified' => 
  array (
    'width' => '15%',
    'label' => 'LBL_DATE_MODIFIED',
    'name' => 'date_modified',
    'default' => false,
  ),
  'created_by' => 
  array (
    'width' => '8%',
    'label' => 'LBL_CREATED',
    'name' => 'created_by',
    'default' => false,
  ),
  'assigned_user_name' => 
  array (
    'width' => '8%',
    'label' => 'LBL_LIST_ASSIGNED_USER',
    'name' => 'assigned_user_name',
    'default' => false,
  ),
);
