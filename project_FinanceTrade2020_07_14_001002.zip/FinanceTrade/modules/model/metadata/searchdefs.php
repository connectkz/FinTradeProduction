<?php
$module_name = 'FinTr_model';
$searchdefs [$module_name] = 
array (
  'layout' => 
  array (
    'basic_search' => 
    array (
      'name' => 
      array (
        'name' => 'name',
        'default' => true,
        'width' => '10%',
      ),
      'fintr_type_fintr_model_name' => 
      array (
        'type' => 'relate',
        'link' => true,
        'label' => 'LBL_FINTR_TYPE_FINTR_MODEL_FROM_FINTR_TYPE_TITLE',
        'id' => 'FINTR_TYPE_FINTR_MODELFINTR_TYPE_IDA',
        'width' => '10%',
        'default' => true,
        'name' => 'fintr_type_fintr_model_name',
      ),
      'fintr_brand_fintr_model_name' => 
      array (
        'type' => 'relate',
        'link' => true,
        'label' => 'LBL_FINTR_BRAND_FINTR_MODEL_FROM_FINTR_BRAND_TITLE',
        'id' => 'FINTR_BRAND_FINTR_MODELFINTR_BRAND_IDA',
        'width' => '10%',
        'default' => true,
        'name' => 'fintr_brand_fintr_model_name',
      ),
    ),
    'advanced_search' => 
    array (
      'name' => 
      array (
        'name' => 'name',
        'default' => true,
        'width' => '10%',
      ),
      'fintr_brand_fintr_model_name' => 
      array (
        'type' => 'relate',
        'link' => true,
        'label' => 'LBL_FINTR_BRAND_FINTR_MODEL_FROM_FINTR_BRAND_TITLE',
        'width' => '10%',
        'default' => true,
        'id' => 'FINTR_BRAND_FINTR_MODELFINTR_BRAND_IDA',
        'name' => 'fintr_brand_fintr_model_name',
      ),
      'fintr_type_fintr_model_name' => 
      array (
        'type' => 'relate',
        'link' => true,
        'label' => 'LBL_FINTR_TYPE_FINTR_MODEL_FROM_FINTR_TYPE_TITLE',
        'width' => '10%',
        'default' => true,
        'id' => 'FINTR_TYPE_FINTR_MODELFINTR_TYPE_IDA',
        'name' => 'fintr_type_fintr_model_name',
      ),
      'serialnumber' => 
      array (
        'type' => 'enum',
        'studio' => 'visible',
        'label' => 'LBL_SERIALNUMBER',
        'width' => '10%',
        'default' => true,
        'name' => 'serialnumber',
      ),
      'merged' => 
      array (
        'type' => 'enum',
        'studio' => 'visible',
        'label' => 'LBL_MERGED',
        'width' => '10%',
        'default' => true,
        'name' => 'merged',
      ),
    ),
  ),
  'templateMeta' => 
  array (
    'maxColumns' => '3',
    'maxColumnsBasic' => '4',
    'widths' => 
    array (
      'label' => '10',
      'field' => '30',
    ),
  ),
);
?>
