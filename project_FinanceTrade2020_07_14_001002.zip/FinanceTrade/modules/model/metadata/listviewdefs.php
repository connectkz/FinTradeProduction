<?php
$module_name = 'FinTr_model';
$listViewDefs [$module_name] = 
array (
  'NAME' => 
  array (
    'width' => '32%',
    'label' => 'LBL_NAME',
    'default' => true,
    'link' => true,
  ),
  'FINTR_BRAND_FINTR_MODEL_NAME' => 
  array (
    'type' => 'relate',
    'link' => true,
    'label' => 'LBL_FINTR_BRAND_FINTR_MODEL_FROM_FINTR_BRAND_TITLE',
    'id' => 'FINTR_BRAND_FINTR_MODELFINTR_BRAND_IDA',
    'width' => '10%',
    'default' => true,
  ),
  'FINTR_TYPE_FINTR_MODEL_NAME' => 
  array (
    'type' => 'relate',
    'link' => true,
    'label' => 'LBL_FINTR_TYPE_FINTR_MODEL_FROM_FINTR_TYPE_TITLE',
    'id' => 'FINTR_TYPE_FINTR_MODELFINTR_TYPE_IDA',
    'width' => '10%',
    'default' => true,
  ),
  'SERIALNUMBER' => 
  array (
    'type' => 'enum',
    'studio' => 'visible',
    'label' => 'LBL_SERIALNUMBER',
    'width' => '10%',
    'default' => true,
  ),
  'MERGED' => 
  array (
    'type' => 'enum',
    'studio' => 'visible',
    'label' => 'LBL_MERGED',
    'width' => '10%',
    'default' => true,
  ),
  'DESCRIPTION' => 
  array (
    'type' => 'text',
    'studio' => 'visible',
    'label' => 'LBL_DESCRIPTION',
    'sortable' => false,
    'width' => '10%',
    'default' => true,
  ),
);
?>
