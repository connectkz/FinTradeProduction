<?php
$module_name = 'FinTr_MoneyOut';
$_object_name = 'fintr_moneyout';
$searchdefs [$module_name] = 
array (
  'layout' => 
  array (
    'basic_search' => 
    array (
      'exps_way' => 
      array (
        'type' => 'enum',
        'studio' => 'visible',
        'label' => 'LBL_EXPS_WAY',
        'width' => '10%',
        'default' => true,
        'name' => 'exps_way',
      ),
      'currency' => 
      array (
        'type' => 'currency',
        'label' => 'LBL_CURRENCY',
        'currency_format' => true,
        'width' => '10%',
        'default' => true,
        'name' => 'currency',
      ),
      'fintr_moneyout_number' => 
      array (
        'type' => 'int',
        'studio' => 
        array (
          'quickcreate' => false,
        ),
        'label' => 'LBL_NUMBER',
        'width' => '10%',
        'default' => true,
        'name' => 'fintr_moneyout_number',
      ),
      'name' => 
      array (
        'name' => 'name',
        'default' => true,
        'width' => '10%',
      ),
      'banking' => 
      array (
        'type' => 'date',
        'label' => 'LBL_BANKING',
        'width' => '10%',
        'default' => true,
        'name' => 'banking',
      ),
    ),
    'advanced_search' => 
    array (
      'exps_way' => 
      array (
        'type' => 'enum',
        'studio' => 'visible',
        'label' => 'LBL_EXPS_WAY',
        'width' => '10%',
        'default' => true,
        'name' => 'exps_way',
      ),
      'currency' => 
      array (
        'type' => 'currency',
        'label' => 'LBL_CURRENCY',
        'currency_format' => true,
        'width' => '10%',
        'default' => true,
        'name' => 'currency',
      ),
      'resolution' => 
      array (
        'name' => 'resolution',
        'default' => true,
        'width' => '10%',
      ),
      'banking' => 
      array (
        'type' => 'date',
        'label' => 'LBL_BANKING',
        'width' => '10%',
        'default' => true,
        'name' => 'banking',
      ),
      'fintr_moneyout_number' => 
      array (
        'name' => 'fintr_moneyout_number',
        'default' => true,
        'width' => '10%',
      ),
      'name' => 
      array (
        'name' => 'name',
        'default' => true,
        'width' => '10%',
      ),
    ),
  ),
  'templateMeta' => 
  array (
    'maxColumns' => '3',
    'maxColumnsBasic' => '4',
    'widths' => 
    array (
      'label' => '10',
      'field' => '30',
    ),
  ),
);
?>
