<?php
$module_name = 'FinTr_FromWarehouse';
$_object_name = 'fintr_fromwarehouse';
$viewdefs [$module_name] = 
array (
  'DetailView' => 
  array (
    'templateMeta' => 
    array (
      'form' => 
      array (
        'buttons' => 
        array (
          0 => 'EDIT',
          1 => 'DUPLICATE',
          2 => 'DELETE',
          3 => 'FIND_DUPLICATES',
        ),
      ),
      'maxColumns' => '2',
      'widths' => 
      array (
        0 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
        1 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
      ),
      'useTabs' => false,
      'tabDefs' => 
      array (
        'DEFAULT' => 
        array (
          'newTab' => false,
          'panelDefault' => 'expanded',
        ),
        'LBL_EDITVIEW_PANEL1' => 
        array (
          'newTab' => false,
          'panelDefault' => 'expanded',
        ),
      ),
      'syncDetailEditViews' => true,
    ),
    'panels' => 
    array (
      'default' => 
      array (
        0 => 
        array (
          0 => 
          array (
            'name' => 'name',
            'comment' => 'The short description of the bug',
            'label' => 'LBL_SUBJECT',
          ),
          1 => 'assigned_user_name',
        ),
        1 => 
        array (
          0 => 
          array (
            'name' => 'valueout',
            'label' => 'LBL_VALUEOUT',
          ),
          1 => 
          array (
            'name' => 'serial_number',
            'label' => 'LBL_SERIAL_NUMBER',
          ),
        ),
        2 => 
        array (
          0 => 'description',
        ),
      ),
      'lbl_editview_panel1' => 
      array (
        0 => 
        array (
          0 => 'fintr_fromwarehouse_number',
          1 => 
          array (
            'name' => 'fintr_warehouse_fintr_fromwarehouse_name',
          ),
        ),
        1 => 
        array (
          0 => 
          array (
            'name' => 'fintr_model_fintr_fromwarehouse_name',
          ),
          1 => 
          array (
            'name' => 'fintr_storageunit_fintr_fromwarehouse_name',
          ),
        ),
        2 => 
        array (
          0 => 
          array (
            'name' => 'fintr_type_fintr_fromwarehouse_name',
          ),
          1 => 
          array (
            'name' => 'fintr_fromwarehouse_fintr_goodscredit_name',
          ),
        ),
        3 => 
        array (
          0 => 
          array (
            'name' => 'fintr_brand_fintr_fromwarehouse_name',
          ),
          1 => '',
        ),
      ),
    ),
  ),
);
?>
