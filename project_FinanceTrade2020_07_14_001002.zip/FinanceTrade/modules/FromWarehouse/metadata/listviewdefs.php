<?php
$module_name = 'FinTr_FromWarehouse';
$OBJECT_NAME = 'FINTR_FROMWAREHOUSE';
$listViewDefs [$module_name] = 
array (
  'NAME' => 
  array (
    'width' => '32%',
    'label' => 'LBL_SUBJECT',
    'default' => true,
    'link' => true,
  ),
  'VALUEOUT' => 
  array (
    'type' => 'decimal',
    'label' => 'LBL_VALUEOUT',
    'width' => '10%',
    'default' => true,
  ),
  'SERIAL_NUMBER' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_SERIAL_NUMBER',
    'width' => '10%',
    'default' => true,
  ),
  'FINTR_TYPE_FINTR_FROMWAREHOUSE_NAME' => 
  array (
    'type' => 'relate',
    'link' => true,
    'label' => 'LBL_FINTR_TYPE_FINTR_FROMWAREHOUSE_FROM_FINTR_TYPE_TITLE',
    'id' => 'FINTR_TYPE_FINTR_FROMWAREHOUSEFINTR_TYPE_IDA',
    'width' => '10%',
    'default' => true,
  ),
  'FINTR_BRAND_FINTR_FROMWAREHOUSE_NAME' => 
  array (
    'type' => 'relate',
    'link' => true,
    'label' => 'LBL_FINTR_BRAND_FINTR_FROMWAREHOUSE_FROM_FINTR_BRAND_TITLE',
    'id' => 'FINTR_BRAND_FINTR_FROMWAREHOUSEFINTR_BRAND_IDA',
    'width' => '10%',
    'default' => true,
  ),
  'FINTR_FROMWAREHOUSE_NUMBER' => 
  array (
    'width' => '5%',
    'label' => 'LBL_NUMBER',
    'link' => true,
    'default' => true,
  ),
  'DATE_ENTERED' => 
  array (
    'type' => 'datetime',
    'label' => 'LBL_DATE_ENTERED',
    'width' => '10%',
    'default' => true,
  ),
  'ASSIGNED_USER_NAME' => 
  array (
    'width' => '9%',
    'label' => 'LBL_ASSIGNED_USER',
    'module' => 'Employees',
    'id' => 'ASSIGNED_USER_ID',
    'default' => true,
  ),
  'FINTR_MODEL_FINTR_FROMWAREHOUSE_NAME' => 
  array (
    'type' => 'relate',
    'link' => true,
    'label' => 'LBL_FINTR_MODEL_FINTR_FROMWAREHOUSE_FROM_FINTR_MODEL_TITLE',
    'id' => 'FINTR_MODEL_FINTR_FROMWAREHOUSEFINTR_MODEL_IDA',
    'width' => '10%',
    'default' => false,
  ),
  'FINTR_STORAGEUNIT_FINTR_FROMWAREHOUSE_NAME' => 
  array (
    'type' => 'relate',
    'link' => true,
    'label' => 'LBL_FINTR_STORAGEUNIT_FINTR_FROMWAREHOUSE_FROM_FINTR_STORAGEUNIT_TITLE',
    'id' => 'FINTR_STORAGEUNIT_FINTR_FROMWAREHOUSEFINTR_STORAGEUNIT_IDA',
    'width' => '10%',
    'default' => false,
  ),
);
?>
